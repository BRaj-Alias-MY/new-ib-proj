import { Component, OnInit } from '@angular/core';
import { AppService } from '../../../app.service';
import { FormControl, FormGroup } from '@angular/forms';
@Component({
  selector: 'app-entrypage',
  templateUrl: './entrypage.component.html',
  styleUrls: ['./entrypage.component.css']
})
export class EntrypageComponent implements OnInit {
  interviews = [];
  pin: any;
  pinResponse = [];
  myForm: FormGroup;
  Verifypin = 'Verify PIN';

  status = localStorage.getItem('status');
  pin2 = localStorage.getItem('pin');
  email = localStorage.getItem('email');
  domain = localStorage.getItem('domain');
  subdomain = localStorage.getItem('subdomain');

  constructor(private service: AppService) {
    this.myForm = this.myFormGroup();
  }

  ngOnInit() {
    this.getInterview();
  }


  getInterview() {

    let email = localStorage.getItem('email');
    //alert(this.email + this.domain + this.subdomain);
    this.service.getInterviews(email, parseInt(this.domain), parseInt(this.subdomain))
      .subscribe(resp => { this.interviews = resp; console.log(resp) }, err => console.log(err));
  }
  onSubmit(myForm) {
    this.pin = myForm["pin"];
    console.log(this.pin);
    localStorage.setItem('pin', this.pin);
    this.service.getPin(this.pin).subscribe(resp => { this.pinResponse = resp; console.log(this.pinResponse); localStorage.setItem('InterviewId', resp['InterviewId']); localStorage.setItem('status', resp['status']) }, err => console.log(err));
  }
  myFormGroup() {
    return new FormGroup({
      pin: new FormControl()
    })
  }


}
