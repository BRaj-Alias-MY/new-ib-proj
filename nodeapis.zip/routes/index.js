const AsyncTest = require ('../controllers/asynctest.controller');
const Async = require ('../controllers/asyncinterview.controller');
const AsyncMock = require ('../controllers/asyncmock.controller');
const verify = require ('../middleware/auth').verifyToken;
module.exports = app => {
  // app.get ('/api/all', verify, Company.findAll);
  app.get ('/api/asynctest/:InterviewId/:userId/:status', AsyncTest.findOne);
  app.post ('/api/update2', AsyncTest.UpdateRecord);
  app.get ('/api/async/:email/:domain/:subdomain', Async.findAll);
  app.get ('/api/verifypin/:pin', Async.VerifyPin);
  app.post ('/api/updatepin/', Async.UpdatePin);
  app.get ('/api/asyncmock/:InterviewId', AsyncMock.asyncmock);
  app.get ('/api/getinterviews/:status/:email/', Async.findAInterviews);
  app.get ('/api/getvideos/:email/:InterviewId', AsyncTest.getVideos);
};
