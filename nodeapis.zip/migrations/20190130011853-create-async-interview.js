'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.createTable ('AsyncInterviews', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      InterviewId: {
        type: Sequelize.INTEGER,
      },
      email: {
        type: Sequelize.STRING,
      },
      link: {
        type: Sequelize.TEXT,
      },
      pin: {
        type: Sequelize.INTEGER,
      },
      status: {
        type: Sequelize.ENUM,
        values: ['Available', 'Verified', 'Submitted', 'Completed', 'Reviewed'],
      },
      paymentstatus: {
        type: Sequelize.ENUM,
        values: ['Pending', 'Success'],
      },

      packageType: {
        type: Sequelize.STRING,
      },
      price: {
        type: Sequelize.FLOAT,
      },
      unvId: {
        type: Sequelize.INTEGER,
      },
      createdBy: {
        type: Sequelize.INTEGER,
      },
      discount: {
        type: Sequelize.FLOAT,
      },
      domain: {
        type: Sequelize.INTEGER,
      },
      subdomain: {
        type: Sequelize.INTEGER,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.dropTable ('AsyncInterviews');
  },
};
