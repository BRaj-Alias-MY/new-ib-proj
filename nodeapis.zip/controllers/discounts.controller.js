const Discount = require('../models').Discount;

exports.Create = (req,res) => {
    Discount.create({
        course_id: req.body.course_id,
        amount: req.body.amount

    })
    .then(discount => {res.json(discount)})
    .then(err => {res.json(err)});
}