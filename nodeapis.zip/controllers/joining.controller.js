const Joining = require('../models').Joining;

exports.Create = (req, res) => {
    Joining.create ({
      course_id : req.body.course_id,
      student_id: req.body.student_id
    })
      .then (response => {
        res.send (response);
        console.log(response);
      })
      .catch (err => {
        res.send ('unable to access ');
      });
  };

  exports.Find = (req,res) => {
    Joining.findAll({}).then(response=> res.send(response)).then(err=> {res.send(err)});

  }