const companies = require ('./companies');

module.exports = {
  companies,
};
